package com.example.ecommerce.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.ecommerce.model.Product;

@Service
public class ProductService {
    private List<Product> products;

    public ProductService() {
        products = new ArrayList<>();
        products.add(new Product("1", "Product 1", 100.0, "Description for product 1"));
        products.add(new Product("2", "Product 2", 150.0, "Description for product 2"));
        products.add(new Product("3", "Product 3", 200.0, "Description for product 3"));
    }

    public List<Product> getAllProducts() {
        return products;
    }

    public Product getProductById(String id) {
        return products.stream().filter(p -> p.getId().equals(id)).findFirst().orElse(null);
    }
}

